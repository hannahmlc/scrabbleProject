package game;

public enum FieldType {
    CENTER,DOUBLE_L,DOUBLE_W,TRIPLE_L,TRIPLE_W,NORMAL;
}
