package game.interfaces;

public interface Player {
}
