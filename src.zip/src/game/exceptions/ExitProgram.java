package game.exceptions;

public class ExitProgram extends Throwable {
    public ExitProgram(String msg) {
        super(msg);
    }
}
