package game;
//import WordChecker.java.*;



public class testtes {/*
    public static void main(String[] args) {
        String word = "dog";
        testtes test = new testtes();
        test.Print("dog");
    }


    public boolean isWord(String word){
        FileStreamScrabbleWordChecker checker = new FileStreamScrabbleWordChecker();
        ScrabbleWordChecker.WordResponse response = checker.isValidWord(word);
        if(response == null){
            return false;
        }
        else{
            return true;
        }
    }

    public void Print(String word){
        if(isWord(word)) System.out.println("yes");
        else System.out.println("no");
    }
}*/
}
