package game;


public class TODO {

    //TODO: make the game polayble on server client instead of programm closing after printing baord once

    //TODO: HANDLE BLANK TILES
    //TODO: player can use tiles they dont have
    //TODO: CHECKING IF WORD EXIST BASICALLY DOESNT WORK IF THE WORD START WITH ALREADY PLACED TILES
}
